import React from 'react';
import { Grid } from '@mui/material';
import { Route, Routes } from 'react-router-dom';
import Navigation from '../Navigation/Navigation';
import WorkoutsSection from '../WorkoutsSection/WorkoutsSection';
import WorkoutDetails from '../WorkoutsSection/WorkoutDetails';
import PostList from '../Posts/PostList';
import CreatePost from '../Posts/CreatePost';
import FriendSuggestions from '../FriendSuggestions/FriendSuggestions'; // Import the FriendSuggestions component

const HomePage = () => {
    return (
        <Grid container xs={12} className='h-screen'>
            {/* Left navigation */}
            <Grid item xs={12} lg={2.5} className='hidden lg:block relative'>
                <Navigation />
            </Grid>

            {/* Middle content area */}
            <Grid item xs={12} lg={7} className='relative'>
                <Routes>
                    {/* Define routes */}
                    <Route path="/home" element={<PostList />} />
                    <Route path="/myworkouts/:id" element={<WorkoutsSection />} />
                    <Route path="/workoutDetail/:id" element={<WorkoutDetails />} />
                    <Route path="/create-post" element={<CreatePost />} />
                    <Route path="/post-list" element={<PostList />} />
                </Routes>
            </Grid>

            {/* Right section for friend suggestions */}
            <Grid item xs={12} lg={2.5} className='hidden lg:block relative'>
                <FriendSuggestions />
            </Grid>
        </Grid>
    );
};

export default HomePage;
