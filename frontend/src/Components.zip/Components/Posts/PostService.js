import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080/api/posts';

const getAllPosts = async () => {
    const response = await axios.get(API_BASE_URL);
    return response.data;
};

const getPostById = async (id) => {
    const response = await axios.get(`${API_BASE_URL}/${id}`);
    return response.data;
};

const createPost = async (post) => {
    const response = await axios.post(API_BASE_URL, post);
    return response.data;
};

const updatePost = async (id, post) => {
    const response = await axios.put(`${API_BASE_URL}/${id}`, post);
    return response.data;
};

const deletePost = async (id) => {
    const response = await axios.delete(`${API_BASE_URL}/${id}`);
    return response.data;
};

export { getAllPosts, getPostById, createPost, updatePost, deletePost };
