import React, { useState, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPost } from './PostService';
import { FaSmile } from 'react-icons/fa';
import EmojiPicker from 'emoji-picker-react';

const CreatePost = ({ onClose }) => {
    const navigate = useNavigate();
    const [post, setPost] = useState({
        username: '',
        content: '',
        media: [],
    });

    const [showEmojiPicker, setShowEmojiPicker] = useState(false);

    const handleInputChange = useCallback((e) => {
        const { name, value } = e.target;
        setPost((prevPost) => ({
            ...prevPost,
            [name]: value,
        }));
    }, []);

    const handleMediaChange = useCallback((e) => {
        const files = Array.from(e.target.files);
        setPost((prevPost) => ({
            ...prevPost,
            media: files,
        }));
    }, []);

    const handleEmojiSelect = useCallback((event, emojiObject) => {
        if (emojiObject && emojiObject.emoji) {
            setPost((prevPost) => ({
                ...prevPost,
                content: prevPost.content + emojiObject.emoji,
            }));
        }
        setShowEmojiPicker(false);
    }, []);

    const handleSubmit = useCallback(async (e) => {
        e.preventDefault();
        try {
            const newPost = await createPost(post);
            navigate(`/posts/${newPost.id}`);
            // Close the dialog once the post is created successfully
            onClose();
        } catch (error) {
            console.error('Error creating post:', error);
        }
    }, [navigate, post, onClose]);

    const emojiPickerElement = useMemo(() => (
        showEmojiPicker && (
            <div className="absolute right-0 top-12 z-10 bg-white shadow-lg rounded-md">
                <EmojiPicker onEmojiClick={handleEmojiSelect} />
            </div>
        )
    ), [showEmojiPicker, handleEmojiSelect]);

    const mediaPreview = useMemo(() => (
        post.media.length > 0 && (
            <div className="mt-2 grid grid-cols-2 md:grid-cols-3 gap-3">
                {post.media.map((file, index) => (
                    <div key={index} className="relative">
                        <img
                            src={URL.createObjectURL(file)}
                            alt={`Preview ${index}`}
                            className="w-full h-auto rounded-lg"
                        />
                    </div>
                ))}
            </div>
        )
    ), [post.media]);

    return (
        <div className="p-6 bg-white rounded-lg shadow-md" style={{ width: '100%' }}>
            {/* Heading */}
            <h2 className="text-2xl font-bold text-green-600 mb-4">Create Post</h2>

            {/* Create Post Form */}
            <form onSubmit={handleSubmit}>
                {/* Username input */}
                <div className="mb-4">
                    <label htmlFor="username" className="block text-sm font-medium text-gray-700">
                        Username:
                    </label>
                    <input
                        type="text"
                        id="username"
                        name="username"
                        value={post.username}
                        onChange={handleInputChange}
                        className="mt-1 w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-600"
                        required
                    />
                </div>

                {/* Content input with emoji picker */}
                <div className="mb-4 relative">
                    <div className="flex items-center justify-between">
                        <label htmlFor="content" className="block text-sm font-medium text-gray-700">
                            What's on your mind?
                        </label>
                        <button
                            type="button"
                            className="ml-2 text-gray-500 hover:text-green-600"
                            onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                        >
                            <FaSmile />
                        </button>
                    </div>
                    <textarea
                        id="content"
                        name="content"
                        value={post.content}
                        onChange={handleInputChange}
                        className="mt-1 w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-600 h-32"
                        required
                    ></textarea>
                    {emojiPickerElement}
                </div>

                {/* Media file upload input */}
                <div className="mb-4">
                    <label htmlFor="media" className="block text-sm font-medium text-gray-700">
                        Add Photos/Video:
                    </label>
                    <input
                        type="file"
                        id="media"
                        name="media"
                        accept="image/*, video/*"
                        multiple
                        onChange={handleMediaChange}
                        className="mt-1 w-full text-gray-700"
                    />
                    {mediaPreview}
                </div>

                {/* Submit button */}
                <div className="mt-4">
                    <button
                        type="submit"
                        className="w-full py-3 bg-green-600 text-white rounded-md font-semibold hover:bg-green-700 transition duration-200 ease-in-out"
                    >
                        Post
                    </button>
                </div>
            </form>
        </div>
    );
};

export default CreatePost;
