import React, { useEffect, useState } from 'react';
import { getAllPosts } from './PostService'; // Import your post service

const PostList = () => {
    const [posts, setPosts] = useState([]);

    useEffect(() => {
        async function fetchPosts() {
            try {
                const postsData = await getAllPosts();
                setPosts(postsData);
            } catch (error) {
                console.error('Error fetching posts:', error);
            }
        }

        fetchPosts();
    }, []);

    return (
        <div>
            <h2>Posts</h2>
            {posts.map((post) => (
                <div key={post.id}>
                    <h3>{post.title}</h3>
                    <p>{post.content}</p>
                    <p>By: {post.username}</p>
                    <p>Likes: {post.likes}</p>
                    <p>Important: {post.isImportant ? 'Yes' : 'No'}</p>
                </div>
            ))}
        </div>
    );
};

export default PostList;
