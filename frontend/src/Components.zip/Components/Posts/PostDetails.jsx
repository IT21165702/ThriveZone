import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';

const PostDetails = () => {
    const { postId } = useParams(); // Retrieve the post ID from the URL parameters
    const [post, setPost] = useState(null);
    const [commentText, setCommentText] = useState('');

    // Define dummy data
    const dummyData = [
        {
            id: '1',
            title: 'Post 1',
            content: 'This is the content of Post 1.',
            username: 'User1',
            likes: 10,
            isImportant: false,
            media: 'https://example.com/image1.jpg',
            comments: [
                { username: 'UserA', text: 'Great post!' },
                { username: 'UserB', text: 'Nice content!' }
            ]
        },
        {
            id: '2',
            title: 'Post 2',
            content: 'This is the content of Post 2.',
            username: 'User2',
            likes: 15,
            isImportant: true,
            media: 'https://example.com/video2.mp4',
            comments: [
                { username: 'UserC', text: 'Very informative.' },
                { username: 'UserD', text: 'Thanks for sharing!' }
            ]
        },
        // Add more dummy posts as needed
    ];

    // Fetch the post details based on the post ID
    useEffect(() => {
        const fetchPost = () => {
            // Simulate fetching the post by ID
            const foundPost = dummyData.find((post) => post.id === postId);
            setPost(foundPost);
        };
        fetchPost();
    }, [postId]);

    // Handle adding a comment to the post
    const handleAddComment = () => {
        if (commentText.trim() !== '') {
            // Update the comments array in the post state
            setPost((prevPost) => ({
                ...prevPost,
                comments: [...prevPost.comments, { username: 'CurrentUser', text: commentText }],
            }));
            // Reset the comment text
            setCommentText('');
        }
    };

    // Handle adding a like to the post
    const handleAddLike = () => {
        setPost((prevPost) => ({
            ...prevPost,
            likes: prevPost.likes + 1,
        }));
    };

    if (!post) {
        return <p>Loading post...</p>;
    }

    return (
        <div className="max-w-md mx-auto p-4 bg-white rounded-lg shadow-md">
            <h2 className="text-2xl font-bold mb-4">{post.title}</h2>
            <p className="text-gray-700 mb-4">{post.content}</p>
            {/* Display media if available */}
            {post.media && (
                <div className="mb-4">
                    {post.media.endsWith('.jpg') || post.media.endsWith('.jpeg') || post.media.endsWith('.png') ? (
                        <img src={post.media} alt="Post media" className="w-full h-auto rounded-lg" />
                    ) : (
                        <video controls className="w-full h-auto rounded-lg">
                            <source src={post.media} type="video/mp4" />
                            Your browser does not support the video tag.
                        </video>
                    )}
                </div>
            )}
            <p>By: {post.username}</p>
            <div className="flex justify-between items-center mt-4">
                <button
                    className="px-4 py-2 bg-blue-500 text-white rounded-md"
                    onClick={handleAddLike}
                >
                    Like ({post.likes})
                </button>
                {post.isImportant && <span className="text-yellow-500">Important</span>}
            </div>
            <div className="mt-4">
                <h3 className="text-lg font-bold mb-2">Comments:</h3>
                {post.comments && post.comments.length > 0 ? (
                    post.comments.map((comment, index) => (
                        <div key={index} className="mb-2">
                            <p className="text-gray-700"><strong>{comment.username}:</strong> {comment.text}</p>
                        </div>
                    ))
                ) : (
                    <p className="text-gray-500">No comments yet.</p>
                )}
                <textarea
                    className="w-full p-2 border border-gray-300 rounded-md mb-2"
                    placeholder="Add a comment..."
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                />
                <button
                    className="w-full py-2 bg-blue-600 text-white rounded-md"
                    onClick={handleAddComment}
                >
                    Add Comment
                </button>
            </div>
        </div>
    );
};

export default PostDetails;
