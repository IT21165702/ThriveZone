import React, { useState, useEffect } from 'react';
import { Dialog, DialogTitle, DialogContent, DialogActions, Button, Avatar } from '@mui/material';
import DialogContentText from '@mui/material/DialogContentText';
import FavoriteIcon from '@mui/icons-material/Favorite';

const PostList = () => {
    const [posts, setPosts] = useState([]);
    const [selectedPost, setSelectedPost] = useState(null);
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [newComment, setNewComment] = useState('');

    // Simulate fetching posts from a server
    useEffect(() => {
        const dummyPosts = [
            {
                id: '1',
                content: 'Just completed an intense workout session!',
                username: 'FitUser',
                profilePicture: 'https://via.placeholder.com/50/0000FF', // User profile picture URL
                likes: 15,
                comments: ['Great job!', 'Nice workout!'],
                media: 'https://via.placeholder.com/300/0000FF', // Example media URL
            },
            {
                id: '2',
                content: 'Delicious healthy meal prep for the week!',
                username: 'FoodieGal',
                profilePicture: 'https://via.placeholder.com/50/008000', // User profile picture URL
                likes: 20,
                comments: ['Looks yummy!', 'Great recipe!'],
                media: 'https://via.placeholder.com/300/008000', // Example media URL
            },
            {
                id: '3',
                content: 'Explored new hiking trails this weekend!',
                username: 'HikerDude',
                profilePicture: 'https://via.placeholder.com/50/FF0000', // User profile picture URL
                likes: 10,
                comments: ['Beautiful views!', 'Where was this?'],
                media: 'https://via.placeholder.com/300/FF0000', // Example media URL
            },
        ];
        setPosts(dummyPosts);
    }, []);

    // Handle post click to display post details in a dialog
    const handlePostClick = (post) => {
        setSelectedPost(post);
        setIsDialogOpen(true);
    };

    // Handle closing the dialog
    const handleCloseDialog = () => {
        setIsDialogOpen(false);
        setSelectedPost(null);
        setNewComment('');
    };

    // Handle the like button click
    const handleLikeClick = (postId) => {
        setPosts((prevPosts) =>
            prevPosts.map((post) =>
                post.id === postId ? { ...post, likes: post.likes + 1 } : post
            )
        );
    };

    // Handle adding a new comment
    const handleAddComment = () => {
        if (newComment.trim()) {
            setPosts((prevPosts) =>
                prevPosts.map((post) =>
                    post.id === selectedPost.id
                        ? { ...post, comments: [...post.comments, newComment] }
                        : post
                )
            );
            setNewComment('');
        }
    };

    return (
        <div className="w-full p-4">
            <h2 className="text-2xl font-bold mb-4">Posts</h2>

            {/* Display the list of posts */}
            {posts.map((post) => (
                <div key={post.id} className="bg-white shadow-lg rounded-lg p-4 mb-6">
                    <div onClick={() => handlePostClick(post)} className="cursor-pointer">
                        {/* Display the user profile picture and username */}
                        <div className="flex items-center mb-2">
                            <Avatar src={post.profilePicture} alt={post.username} />
                            <span className="text-gray-800 font-semibold ml-2">{post.username}</span>
                        </div>

                        <p className="text-gray-700 mb-2">{post.content}</p>

                        {/* Display likes and comments */}
                        <div className="flex items-center justify-between text-gray-600 text-sm">
                            <div>
                                <span>Likes: {post.likes}</span>
                            </div>
                            <div>
                                <span>Comments: {post.comments.length}</span>
                            </div>
                        </div>

                        {/* Display media at the bottom of the post */}
                        {post.media && (
                            <div className="mt-2">
                                {post.media.endsWith('.jpg') || post.media.endsWith('.jpeg') || post.media.endsWith('.png') ? (
                                    <img src={post.media} alt="Post media" className="w-full h-auto rounded-lg" />
                                ) : (
                                    <video controls className="w-full h-auto rounded-lg">
                                        <source src={post.media} type="video/mp4" />
                                        Your browser does not support the video tag.
                                    </video>
                                )}
                            </div>
                        )}
                    </div>

                    {/* Like button with heart icon */}
                    <div className="flex justify-end mt-2">
                        <Button
                            variant="contained"
                            color="success"
                            size="small"
                            onClick={(e) => {
                                e.stopPropagation(); // Prevent opening dialog when clicking the button
                                handleLikeClick(post.id);
                            }}
                            startIcon={<FavoriteIcon />} // Add the heart icon
                        >
                            Like
                        </Button>
                    </div>
                </div>
            ))}

            {/* Dialog for displaying post details */}
            <Dialog open={isDialogOpen} onClose={handleCloseDialog} fullWidth maxWidth="md">
                <DialogTitle>Post Details</DialogTitle>
                <DialogContent>
                    {selectedPost && (
                        <>
                            <DialogContentText>
                                <strong>Username:</strong> {selectedPost.username}
                            </DialogContentText>
                            <DialogContentText>
                                <strong>Content:</strong> {selectedPost.content}
                            </DialogContentText>
                            <DialogContentText>
                                <strong>Likes:</strong> {selectedPost.likes}
                            </DialogContentText>
                            <DialogContentText>
                                <strong>Comments:</strong> {selectedPost.comments.join(', ')}
                            </DialogContentText>
                            {selectedPost.media && (
                                <>
                                    {selectedPost.media.endsWith('.jpg') || selectedPost.media.endsWith('.jpeg') || selectedPost.media.endsWith('.png') ? (
                                        <img src={selectedPost.media} alt="Post media" className="w-full h-auto rounded-lg mt-4" />
                                    ) : (
                                        <video controls className="w-full h-auto rounded-lg mt-4">
                                            <source src={selectedPost.media} type="video/mp4" />
                                            Your browser does not support the video tag.
                                        </video>
                                    )}
                                </>
                            )}
                        </>
                    )}
                    {/* Comment input and button */}
                    <div className="mt-4">
                        <textarea
                            value={newComment}
                            onChange={(e) => setNewComment(e.target.value)}
                            placeholder="Add a comment..."
                            className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-600 h-20"
                        ></textarea>
                        <Button
                            variant="contained"
                            color="success"
                            onClick={handleAddComment}
                            className="mt-2"
                        >
                            Add Comment
                        </Button>
                    </div>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseDialog} color="primary">
                        Close
                    </Button>
                </DialogActions>
            </Dialog>
        </div>
    );
};

export default PostList;
