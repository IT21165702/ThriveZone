// WorkoutsSection.js
import React from 'react';
import { useState } from 'react'

import { Button } from '@mui/material';
import { Link } from 'react-router-dom';
import WorkoutCard from './WorkoutCard';
import WorkoutModal from './WorkoutModal';
import { Route, Routes } from 'react-router-dom';

const WorkoutsSection = () => {

    const [openWorkoutModal, setOpenWorkoutModal] = useState(false);
    const handleOpenWorkoutModal = () => setOpenWorkoutModal(true);
    const handleClose = () => setOpenWorkoutModal(false);
    return (
        <div>
            <section className={`z-50 flex items-center top-0 bg-opacity-95`}>
                <h1 className='py-8 pb-4 text-x1 font-bold opacity-90 pl-20' >My Workouts</h1>
            </section>
            <section>
                <div className='py-10'>
                    {/* Link to navigate to the form page */}
                    <Link to="/form">

                    </Link>
                    <Button
                        sx={{ width: "50%", borderRadius: "29px", py: "15px", bgcolor: '#1e88e5' }}
                        variant='contained'
                        onClick={handleOpenWorkoutModal}
                    >
                        Create A New Workout
                    </Button>
                </div>
            </section>
            <section>
                <WorkoutModal handleClose={handleClose} open={openWorkoutModal} />
            </section>
            <section>
                {[1, 1, 1, 1, 1].map((item) => <WorkoutCard />)}

            </section>
        </div>
    );
};

export default WorkoutsSection;
