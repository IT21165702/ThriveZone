import React, { useState } from 'react'
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import { useNavigate } from 'react-router-dom';
import WorkoutCard from './WorkoutCard';
import { useFormik } from 'formik';
import { IconButton } from '@mui/material'
import { TextField } from "@mui/material";
import CloseIcon from '@mui/icons-material/Close';
import Button from '@mui/material/Button';
import './WorkoutModal.css'

const WorkoutDetails = () => {

    const navigate = useNavigate();
    const handleBack = () => navigate(-1);

    const handleSubmit = (values) => {
        console.log("handle submit", values);
    };

    const formik = useFormik({
        initialValues: {
            fullName: "",
            website: "",
            location: "",
            bio: "",

        },
        onSubmit: handleSubmit
    })

    return (
        <div>
            <React.Fragment>

                <section className={`bg-white z-50 fle items-center sticky top-0 bg-opacity-95`}>
                    <KeyboardBackspaceIcon
                        className="cursor-pointer"
                        onClick={handleBack}
                    />

                    <h1 className="py-5 text-x1 font-bold opacity-90 ml-5">
                        Workout
                    </h1>
                </section>
                <section>
                    <form onSubmit={formik.handleSubmit}>
                        <div className='flex items-center justify-between'>
                            
                        </div>
                        <div className=" hideScrollBar overflow-y-scroll overflow-x-hidden h-[80vh]">
                            <React.Fragment>
                                <div className='pb-5'>
                                </div>
                            </React.Fragment>
                            <div className="space-y-3 pb-5">
                                <TextField
                                    fullWidth
                                    id="fullName"
                                    name="fullName"
                                    label="Full Name"
                                    value={formik.values.fullName}
                                    onChange={formik.handleChange}
                                    error={formik.touched.fullName && Boolean(formik.errors.fullName)}
                                    helperText={formik.touched.fullName && formik.errors.fullName}
                                />

                                <TextField
                                    fullWidth
                                    id="bio"
                                    name="bio"
                                    label="Bio"
                                    value={formik.values.bio}
                                    onChange={formik.handleChange}
                                    error={formik.touched.bio && Boolean(formik.errors.bio)}
                                    helperText={formik.touched.bio && formik.errors.bio}
                                />

                                <TextField
                                    fullWidth
                                    id="website"
                                    name="website"
                                    label="Website"
                                    value={formik.values.website}
                                    onChange={formik.handleChange}
                                    error={formik.touched.website && Boolean(formik.errors.website)}
                                    helperText={formik.touched.website && formik.errors.website}
                                />

                                <TextField
                                    fullWidth
                                    id="location"
                                    name="location"
                                    label="Location"
                                    value={formik.values.location}
                                    onChange={formik.handleChange}
                                    error={formik.touched.location && Boolean(formik.errors.location)}
                                    helperText={formik.touched.location && formik.errors.location}
                                />

                            </div>
                        </div>
                    </form>
                </section>

                <section>

                </section>

            </React.Fragment>
        </div>
    )
}

export default WorkoutDetails