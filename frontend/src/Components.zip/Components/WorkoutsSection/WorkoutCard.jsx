import React from 'react'
import { Avatar } from '@mui/material';
import { useNavigate } from 'react-router-dom'
import { Button, Menu, MenuItem } from '@mui/material';
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";


const WorkoutCard = () => {
    const navigate = useNavigate();
    const [anchorEl, setAnchorEl] = React.useState(null);
    const open = Boolean(anchorEl);
    const handleClickWorkout = (event) => {
        setAnchorEl(event.currentTarget);
    };
    const handleCloseWorkout = () => {
        setAnchorEl(null);
    };
    const handleDeleteWorkout = () => {
        console.log("Delete Workout")
        handleCloseWorkout();
    }
    return (
        <div className=''>

            <div className='flex items-center font-semibold text-gray-700 py-2'>

                <p>XXX</p>
            </div>
            <div className='flex space-x-5'>
                {/*<Avatar
                    onClick={() => navigate(`/myworkouts`)}
                    className='cursor-pointer'
                    alt='username'
                    src=''
    />*/}
                <div className='w-full border border-gray-300 p-4 rounded cursor-pointer' 
                onClick={()=> navigate(`/workoutDetail/${3}`)}>
                    <div className='flex justify-between items-center'>
                        <div className='flex cursor-pointer items-center space-x-2'>

                            <span className='font-semibold text-x1'>Workout 01</span>

                        </div>
                        <div>
                            <Button
                                id="basic-button"
                                aria-controls={open ? "basic-menu" : undefined}
                                aria-haspopout="true"
                                aria-expanded={open ? "true" : undefined}
                                onClick={handleClickWorkout}
                            >
                                <MoreHorizIcon />
                            </Button>
                            <Menu
                                id="basic-menu"
                                anchorEl={anchorEl}
                                open={open}
                                onClose={handleCloseWorkout}
                                MenuListProps={{
                                    "aria-labelledby": "basic-button",
                                }}
                            >
                                <MenuItem onClick={handleDeleteWorkout}>Edit</MenuItem>
                                <MenuItem onClick={handleDeleteWorkout}>Delete</MenuItem>


                            </Menu>
                        </div>

                    </div>

                    <div className="mt-2">
                        <div className="cursor-pointer">
                            <p className="mb-2 p-0">nice workout</p>
                        </div>
                        <div className="py-5 flex flex-wrap justify-between items-center">
                            <div className="space-x-3 flex items-center text-gray-600">
                                
                            </div>
                        </div>
                    </div>

                </div>

            </div>


        </div>
    )
}

export default WorkoutCard