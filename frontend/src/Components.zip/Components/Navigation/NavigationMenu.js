import HomeIcon from '@mui/icons-material/Home'
import FitnessCenterIcon from '@mui/icons-material/FitnessCenter'
import NotificationsIcon from '@mui/icons-material/Notifications'
import MessageIcon from '@mui/icons-material/Home'
import GroupIcon from '@mui/icons-material/Group'
import PendingIcon from '@mui/icons-material/Pending'

export const navigationMenu=[
    {
        title:"Home",
        icon:<HomeIcon/>,
        path:"/home"
    },
    {
        title:"My Workouts",
        icon:<FitnessCenterIcon/>,
        path:"/myworkouts"
    },
    {
        title:"Notifications",
        icon:<NotificationsIcon/>,
        path:"/notifications"
    },
    {
        title:"Messages",
        icon:<MessageIcon/>,
        path:"/messages"
    },
    {
        title:"Communities",
        icon:<GroupIcon/>,
        path:"/communities"
    },
    {
        title:"More",
        icon:<PendingIcon/>,
        path:"/more"
    },
]